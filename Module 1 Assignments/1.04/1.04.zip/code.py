#Evan Wang
#5/31/2022
#This will inform the user about events



	def main():
		name = (input("Hello there what is your name?"))
		string1 = "Yes"
		
		response = (input("Well " + name +  " do you think it's important that people vote?"))
		if response.lower() == string1.lower():
			print("Well that's a good point as people should vote on important issues such as global warming and taxes.")
		else: 
			print("Sorry you feel that way but people should vote on important issues such as global warming and taxes.")
			
		age = int(input("Say " + name + "how old are you?"))
		x = 18 - age
		if x > 0:
			print("Well you will be able to vote in " + x)
		else:
			print("Well you can vote right now!")
		







	main()