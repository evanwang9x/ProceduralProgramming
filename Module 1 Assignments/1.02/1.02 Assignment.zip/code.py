# Evan Wang
# 5/31/2022
# This Program simulates the conversation between Sammy and a Computer

def main(): 
	name = (input("Please enter your name: "))
	print("Hi there " + name + ".")
	print("Computational thinking can algorithmically solve problems for you!")
	print("fairwell " + name + ".")



main()