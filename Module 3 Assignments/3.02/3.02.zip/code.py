#Evan Wang
#6/1/2022
#A custom game
def main():
	import random
	print("Welcome to Escape Bob the Clown")
	print("You will have to escape bob the clown before he gets you D:")
	
	response = (input("You see a phone ringing in front of you do you pick it up?"))
	if response.lower() == "Yes":
		print("Game over, the phone was actually Bob cleverly disguised and he got you!")
	else:
		response1 = (input("After walking past the phone you see an overly sized toy hammer do you pick it up?"))
		if response1.lower() == "No":
			print("Due to taking too long to do anything, Bob bum rushed you and caught you.")
		else:
			print("The moment you picked up the hammer Bob charged you! Prepare for battle.")
			bobHealth = 100
			while bobHealth > 0: 
				damage = random.randint(20,40)
				bobHealth -= damage
				
				if damage > 30:
					print("What a critical hit, Bob the clown took: " + str(damage) + " and only has: " + str(bobHealth) + " left.")
				else:
				    print("Bob took " + str(damage) + "damage and has " + str(bobHealth) + " left")
			print("Bob has fainted and you have escaped, good job traveler")

main()