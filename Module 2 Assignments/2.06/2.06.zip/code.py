#Evan Wang
#6/1/2022
#To help you decide what to wear

def main():
	#Declaring some values to use in float for later
	male_BaseCost = 25.25
	female_BaseCost = 26.26
	childCost = 15
	teenCost = 25
	adultCost = 35
	seniorCost = 45
	poorCost = 10
	midCost = 50
	richCost = 100
	tax_cost = 1.07

	name = (input("Hello there, what is your name?"))
	print("Hello there " + name + " welcome to Evan's Clothing Store!")
	print("")
	print("Hi " + name + " please answer the following questions to determine the perfect outfit for your next vacation!")
	print("***********************************")
	age = int(input("How old are you " + name + "?"))
	gender = (input("What is your gender?"))
	wealth = int(input("What is your budget for you clothes?"))
	
	
	if gender.lower() == "male":
		if age < 12:
			if wealth < 20:
				final_cost = ((male_BaseCost + float(childCost) + float(poorCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for male children on a budget"
			elif wealth > 20 and wealth < 100:
				final_cost = ((male_BaseCost + float(childCost) + float(midCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for male children on a fair budget"
			else:
				final_cost = ((male_BaseCost + float(childCost) + float(richCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for male children on no budget"
		elif age > 12 and age < 18:
			if wealth < 20:
				final_cost = ((male_BaseCost + float(teenCost) + float(poorCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for male teens on a budget"
			elif wealth > 20 and wealth < 100:
				final_cost = ((male_BaseCost + float(teenCost) + float(midCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for male teens on a fair budget"
			else:
				((male_BaseCost + float(teenCost) + float(richCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for male teens on no budget"
		elif age > 18 and age < 65:
			if wealth < 20:
				final_cost = ((male_BaseCost + float(adultCost) + float(poorCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for men on a budget"
			elif wealth > 20 and wealth < 100:
				final_cost = ((male_BaseCost + float(adultCost) + float(midCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for men on a fair budget"
			else:
				final_cost = ((male_BaseCost + float(adultCost) + float(richCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for men on no budget"
		else:
			if wealth < 20:
				final_cost = ((male_BaseCost + float(seniorCost) + float(poorCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for senior men on a budget"
			elif wealth > 20 and wealth < 100:
				final_cost = ((male_BaseCost + float(seniorCost) + float(midCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for senior men on a fair budget"
			else:
				((male_BaseCost + float(seniorCost) + float(richCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for senior men on no budget"
	else:
		if age < 12:
			if wealth < 20:
				final_cost = ((female_BaseCost + float(childCost) + float(poorCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for female children on a budget"
			elif wealth > 20 and wealth < 100:
				final_cost = ((female_BaseCost + float(childCost) + float(midCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for female children on a fair budget"
			else:
				final_cost = ((female_BaseCost + float(childCost) + float(richCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for female children on no budget"
		elif age > 12 and age < 18:
			if wealth < 20:
				final_cost = ((female_BaseCost + float(teenCost) + float(poorCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for female teens on a budget"
			elif wealth > 20 and wealth < 100:
				final_cost = ((female_BaseCost + float(teenCost) + float(midCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for female teens on a fair budget"
			else:
				final_cost = ((female_BaseCost + float(teenCost) + float(richCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for female teens on no budget"
		elif age > 18 and age < 65:
			if wealth < 20:
				final_cost = ((female_BaseCost + float(adultCost) + float(poorCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for women on a budget"
			elif wealth > 20 and wealth < 100:
				final_cost = ((female_BaseCost + float(adultCost) + float(midCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for women on a fair budget"
			else:
				final_cost = ((female_BaseCost + float(adultCost) + float(richCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for men on no budget"
		else:
			if wealth < 20:
				final_cost = ((female_BaseCost + float(seniorCost) + float(poorCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for senior women on a budget"
			elif wealth > 20 and wealth < 100:
				final_cost = ((female_BaseCost + float(seniorCost) + float(midCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for senior women on a fair budget"
			else:
				final_cost = ((female_BaseCost + float(seniorCost) + float(richCost)) * tax_cost)
				evanCustomFit = "Evan's perfect attire for senior women on no budget"
		
	print("Hello with your budget of: " + str(wealth) + " we have decided that the best attire for you would be: " + evanCustomFit + ". This will cost you: " + str(final_cost))
main()