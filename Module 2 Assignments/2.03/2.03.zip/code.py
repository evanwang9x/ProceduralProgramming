#Evan Wang
#6/1/2022
#To help improve online sales

def main():

	print("**************************")
	print("Welcome to the Sock Shop!")
	print("**************************")
	print("")
	print("We are a store that has been passed down generation from generation for 500 years!")
	print("Today we are selling all socks for $5 each. If you spend at more than $100 you get $45.45 off, but if you spend more than $500 you get 255.25 off. Finally if you spend more than $1000 you get $650.45 off !")
	
	response = int(input("How many pairs of socks would you like to buy?"))
	response1 = (input("What color socks would you like to buy?"))
	
	sockCostPrim = response * 5
	if sockCostPrim > 100 and sockCostPrim < 500:
		final_Price = sockCostPrim - 45.45
	elif sockCostPrim > 500 and sockCostPrim < 1000:
		final_Price = sockCostPrim - 255.25
	elif sockCostPrim > 1000:	
		final_Price = sockCostPrim - 650.45
		
		
	print("**************************")
	print("Thank you for shopping here! You bought: " + str(response) + " pairs of " + str(response1).lower() + " red socks. " + "Your original cost before savings was: " + str(sockCostPrim) + " but your purchase will cost: " + str(final_Price))
	print("**************************")
main()